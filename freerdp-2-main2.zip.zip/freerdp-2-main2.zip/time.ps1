$i = 360000
do {
    Write-Host $i
    Sleep 60
    $i--
} while ($i -gt 0)
